#ifndef LIBRARY_H
#define LIBRARY_H

#include <vector>
#include <string>
#include <memory>
#include "resource.h"
#include "user.h"
#include "Loan.h"
#include "event.h"
#include "reservation.h"

class Library {
private:
    std::vector<std::unique_ptr<Resource>> resources;
    std::vector<std::unique_ptr<User>> users;
    std::vector<std::unique_ptr<Loan>> loans;
    std::vector<std::unique_ptr<Reservation>> reservations;
    // Add to Library.h private section:
    std::vector<std::unique_ptr<Event>> events;

    // Add to Library.h public section:


public:
    // Resource management
    void addResource(std::unique_ptr<Resource> resource);
    bool removeResource(const std::string& resourceID);
    Resource* findResource(const std::string& resourceID) const;
    std::vector<Resource*> searchResources(const std::string& query) const;

    // User management
    void addUser(std::unique_ptr<User> user);
    bool removeUser(const std::string& userID);
    User* findUser(const std::string& userID) const;

    // Loan management
    bool borrowResource(const std::string& userID, const std::string& resourceID);
    bool returnResource(const std::string& resourceID);
    std::vector<Loan*> getUserLoans(const std::string& userID) const;

    // Reservation management
    bool makeReservation(const std::string& userID, const std::string& resourceID);
    bool fulfillReservation(const std::string& resourceID);
    std::vector<Reservation*> getResourceReservations(const std::string& resourceID) const;
    // Event management
    void addEvent(std::unique_ptr<Event> event);
    bool removeEvent(const std::string& eventID);
    Event* findEvent(const std::string& eventID) const;
    std::vector<Event*> getUpcomingEvents() const;
    std::vector<Event*> searchEvents(const std::string& query) const;
    bool registerForEvent(const std::string& userID, const std::string& eventID);
    bool cancelEventRegistration(const std::string& userID, const std::string& eventID);

    // Notification system
    void checkDueDates() const;
};

#endif // LIBRARY_H
