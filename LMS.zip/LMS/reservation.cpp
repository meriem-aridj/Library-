#include "reservation.h"

// Constructor
Reservation::Reservation(Resource* resource, User* user, time_t reservationDate)
    : resource(resource), user(user), reservationDate(reservationDate), fulfilled(false) {}

// Getters
Resource* Reservation::getResource() const {
    return resource;
}

User* Reservation::getUser() const {
    return user;
}

time_t Reservation::getReservationDate() const {
    return reservationDate;
}

bool Reservation::isFulfilled() const {
    return fulfilled;
}

// Mark as fulfilled
void Reservation::fulfill() {
    fulfilled = true;
}
