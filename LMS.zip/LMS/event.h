#ifndef EVENT_H
#define EVENT_H

#include <string>
#include <vector>
#include <ctime>

class User; // Forward declaration

class Event {
protected:
    std::string eventID;
    std::string title;
    std::string description;
    time_t startTime;
    time_t endTime;
    std::string location;
    int capacity;
    std::vector<User*> registeredUsers;

public:
    Event(const std::string& id, const std::string& title,
          const std::string& desc, time_t start, time_t end,
          const std::string& loc, int capacity);

    // Virtual destructor for polymorphism
    virtual ~Event() = default;

    // Pure virtual function to make this abstract
    virtual std::string getEventType() const = 0;

    // Common event methods
    virtual bool registerUser(User* user);
    virtual bool cancelRegistration(User* user);
    virtual int getAvailableSeats() const;
    virtual void displayDetails() const;

    // Getters
    virtual std::string getEventID() const;
    virtual std::string getTitle() const;
    virtual std::string getDescription() const;
    virtual time_t getStartTime() const;
    virtual time_t getEndTime() const;
    virtual std::string getLocation() const;
    virtual int getCapacity() const;
    virtual std::vector<User*> getRegisteredUsers() const;
};

#endif // EVENT_H
