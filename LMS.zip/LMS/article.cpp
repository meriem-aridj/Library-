#include "article.h"
#include <iostream>
#include <iostream>
using namespace std ;
// Constructor
Article::Article(const std::string& title, const std::string& author, int year,
                 const std::string& id, const std::string& journal,
                 int volume, int issue, const std::string& doi)
    : Resource(title, author, year, id),
    journalName(journal),
    volume(volume),
    issue(issue),
    DOI(doi) {}

// Override: Display article details
void Article::displayDetails() const {
    std::cout << "=== Article Details ===" << std::endl;
    std::cout << "Title: " << getTitle() << std::endl;
    std::cout << "Author: " << getAuthor() << std::endl;
    std::cout << "Year: " << getPublicationYear() << std::endl;
    std::cout << "ID: " << getUniqueID() << std::endl;
    std::cout << "Journal: " << journalName << std::endl;
    std::cout << "Volume: " << volume << std::endl;
    std::cout << "Issue: " << issue << std::endl;
    std::cout << "DOI: " << DOI << std::endl;
}

// Override: Resource type identifier
std::string Article::getResourceType() const {
    return "Article";
}

// Getters
std::string Article::getJournalName() const {
    return journalName;
}

int Article::getVolume() const {
    return volume;
}

int Article::getIssue() const {
    return issue;
}

std::string Article::getDOI() const {
    return DOI;
}
