#include "workshop.h"

Workshop::Workshop(const std::string& id, const std::string& title,
                   const std::string& desc, time_t start, time_t end,
                   const std::string& loc, int capacity,
                   const std::string& facilitator, const std::string& topic)
    : Event(id, title, desc, start, end, loc, capacity),
    facilitator(facilitator), topic(topic) {}

std::string Workshop::getEventType() const {
    return "Workshop";
}

void Workshop::addMaterial(const std::string& material) {
    materials.push_back(material);
}

std::vector<std::string> Workshop::getMaterials() const {
    return materials;
}

std::string Workshop::getFacilitator() const {
    return facilitator;
}

std::string Workshop::getTopic() const {
    return topic;
}
