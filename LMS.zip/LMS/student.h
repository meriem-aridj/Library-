#ifndef STUDENT_H
#define STUDENT_H

class student
{
public:
    student();
};

#endif // STUDENT_H
