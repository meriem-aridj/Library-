#ifndef EMAILNOTIFICATION_H
#define EMAILNOTIFICATION_H



#include "notification.h"

class EmailNotification : public Notification {
public:
    void send(const std::string& recipient, const std::string& message) const override;
};

#endif // EMAILNOTIFICATION_H
