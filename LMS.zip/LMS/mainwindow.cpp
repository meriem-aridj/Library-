#include "mainwindow.h"
#include <QApplication>
#include <QHeaderView>
#include <QStyleFactory>
#include <QComboBox>
#include <QLineEdit>
#include <QLineEdit>
#include <QMessageBox>
#include <QStackedWidget>
#include <QLineEdit>
#include <QComboBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    stackedWidget(new QStackedWidget(this)),
    mainMenuPage(new QWidget),
    booksPage(new QWidget),
    articlesPage(new QWidget),
    loansPage(new QWidget),
    reservationsPage(new QWidget),
    booksTable(new QTableWidget),
    articlesTable(new QTableWidget),
    loansTable(new QTableWidget),
    reservationsTable(new QTableWidget)
{
    setCentralWidget(stackedWidget);
    setWindowTitle("Library Management System");
    resize(900, 600);
    QApplication::setStyle(QStyleFactory::create("Fusion"));

    setupMainMenu();
    setupBooksPage();
    setupArticlesPage();
    setupLoansPage();
    setupReservationsPage();

    populateSampleData();

    stackedWidget->addWidget(mainMenuPage);
    stackedWidget->addWidget(booksPage);
    stackedWidget->addWidget(articlesPage);
    stackedWidget->addWidget(loansPage);
    stackedWidget->addWidget(reservationsPage);

    stackedWidget->setCurrentWidget(mainMenuPage);
    stackedWidget = new QStackedWidget;
    setupLoginPage(); // 👈 Add this
    setupMainMenu();
    setupBooksPage();
    setupArticlesPage();
    setupLoansPage();
    setupReservationsPage();

    stackedWidget->addWidget(loginPage);
    stackedWidget->addWidget(mainMenuPage);
    stackedWidget->addWidget(booksPage);
    stackedWidget->addWidget(articlesPage);
    stackedWidget->addWidget(loansPage);
    stackedWidget->addWidget(reservationsPage);

    setCentralWidget(stackedWidget);
    stackedWidget->setCurrentWidget(loginPage); // 👈 Show login first
    this->setStyleSheet("QMainWindow { background-color: #f0f0f0; }");
    setWindowTitle("ENSIA LMS");
    resize(800, 600);




}

MainWindow::~MainWindow() {}

void MainWindow::setupMainMenu() {
    auto layout = new QVBoxLayout;
    auto widget = new QWidget;

    auto title = new QLabel("📚 Library Management");
    title->setStyleSheet("font-size: 24px; font-weight: bold; margin-bottom: 20px;");
    title->setAlignment(Qt::AlignCenter);

    auto btnBooks = new QPushButton("Books");
    auto btnArticles = new QPushButton("Articles");
    auto btnLoans = new QPushButton("Loans");
    auto btnReservations = new QPushButton("Reservations");

    for (QPushButton* btn : {btnBooks, btnArticles, btnLoans, btnReservations}) {
        btn->setFixedHeight(40);
        btn->setStyleSheet("font-size: 16px;");
        layout->addWidget(btn);
    }

    layout->insertWidget(0, title);
    layout->setAlignment(Qt::AlignCenter);
    widget->setLayout(layout);

    connect(btnBooks, &QPushButton::clicked, this, &MainWindow::showBooksPage);
    connect(btnArticles, &QPushButton::clicked, this, &MainWindow::showArticlesPage);
    connect(btnLoans, &QPushButton::clicked, this, &MainWindow::showLoansPage);
    connect(btnReservations, &QPushButton::clicked, this, &MainWindow::showReservationsPage);

    mainMenuPage = widget;
}


void MainWindow::setupBooksPage() {
    booksPage = new QWidget;
    QVBoxLayout* layout = new QVBoxLayout(booksPage);

    QLabel* title = new QLabel("Books");
    title->setStyleSheet("font-size: 20px; font-weight: bold; margin-bottom: 8px;");
    layout->addWidget(title);

    // 🔍 Search bar
    booksSearchBox = new QLineEdit;
    booksSearchBox->setPlaceholderText("Search by title or author...");
    booksSearchBox->setStyleSheet("padding: 6px; border-radius: 8px; border: 1px solid #ccc;");
    layout->addWidget(booksSearchBox);

    // 📚 Table
    booksTable = new QTableWidget(0, 3); // Example: title, author, year
    booksTable->setHorizontalHeaderLabels({"Title", "Author", "Year"});
    booksTable->horizontalHeader()->setStretchLastSection(true);
    booksTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    layout->addWidget(booksTable);

    QPushButton* backButton = new QPushButton("Back");
    layout->addWidget(backButton);

    connect(backButton, &QPushButton::clicked, this, &MainWindow::returnToMainMenu);

    // 🧠 Connect filtering
    connect(booksSearchBox, &QLineEdit::textChanged, this, [=](const QString& text){
        for (int row = 0; row < booksTable->rowCount(); ++row) {
            bool match = false;
            for (int col = 0; col < booksTable->columnCount(); ++col) {
                QTableWidgetItem* item = booksTable->item(row, col);
                if (item && item->text().contains(text, Qt::CaseInsensitive)) {
                    match = true;
                    break;
                }
            }
            booksTable->setRowHidden(row, !match);
        }
    });
}


void MainWindow::setupArticlesPage() {
    auto layout = new QVBoxLayout;
    auto backButton = new QPushButton("← Back");
    connect(backButton, &QPushButton::clicked, this, &MainWindow::returnToMainMenu);

    articlesTable->setColumnCount(3);
    articlesTable->setHorizontalHeaderLabels({"Title", "Author", "DOI"});
    articlesTable->horizontalHeader()->setStretchLastSection(true);

    layout->addWidget(backButton);
    layout->addWidget(articlesTable);
    articlesPage->setLayout(layout);
}

void MainWindow::setupLoansPage() {
    auto layout = new QVBoxLayout;
    auto backButton = new QPushButton("← Back");
    connect(backButton, &QPushButton::clicked, this, &MainWindow::returnToMainMenu);

    loansTable->setColumnCount(4);
    loansTable->setHorizontalHeaderLabels({"User", "Resource", "Loan Date", "Due Date"});
    loansTable->horizontalHeader()->setStretchLastSection(true);

    layout->addWidget(backButton);
    layout->addWidget(loansTable);
    loansPage->setLayout(layout);
}

void MainWindow::setupReservationsPage() {
    auto layout = new QVBoxLayout;
    auto backButton = new QPushButton("← Back");
    connect(backButton, &QPushButton::clicked, this, &MainWindow::returnToMainMenu);

    reservationsTable->setColumnCount(3);
    reservationsTable->setHorizontalHeaderLabels({"User", "Resource", "Reservation Date"});
    reservationsTable->horizontalHeader()->setStretchLastSection(true);

    layout->addWidget(backButton);
    layout->addWidget(reservationsTable);
    reservationsPage->setLayout(layout);
}
void MainWindow::setupLoginPage() {
    loginPage = new QWidget;
    QVBoxLayout* layout = new QVBoxLayout(loginPage);
    loginPage->setStyleSheet("background-color: #f5f5f5;");
    QLabel* logo = new QLabel;
    QPixmap logoPixmap(":/images/ensia_logo.png");
    logo->setPixmap(logoPixmap.scaledToWidth(100, Qt::SmoothTransformation));
    logo->setAlignment(Qt::AlignCenter);
    layout->addWidget(logo);


    QLabel* title = new QLabel("ENSIA Library Portal");
    title->setStyleSheet("font-size: 24px; font-weight: 600; margin: 20px;");
    title->setAlignment(Qt::AlignCenter);
    layout->addWidget(title);

    idInput = new QLineEdit;
    idInput->setPlaceholderText("User ID");
    passwordInput = new QLineEdit;
    passwordInput->setPlaceholderText("Password");
    passwordInput->setEchoMode(QLineEdit::Password);

    roleSelector = new QComboBox;
    roleSelector->addItems({"Student", "Faculty", "Guest"});

    loginButton = new QPushButton("Log In");
    loginButton->setStyleSheet("background-color: #007aff; color: white; padding: 8px 16px; border-radius: 10px;");

    QList<QWidget*> widgets = {
        static_cast<QWidget*>(idInput),
        static_cast<QWidget*>(passwordInput),
        static_cast<QWidget*>(roleSelector),
        static_cast<QWidget*>(loginButton)
    };

    for (QWidget* w : widgets) {
        if (w) {
            w->setStyleSheet("padding: 10px; border-radius: 10px; border: 1px solid #ccc; font-size: 14px;");
            layout->addWidget(w);
        }
    }

    connect(loginButton, &QPushButton::clicked, this, [=] {
        // Simple validation and forward
        if (!idInput->text().isEmpty() && !passwordInput->text().isEmpty()) {
            stackedWidget->setCurrentWidget(mainMenuPage); // Forward to main menu
        } else {
            QMessageBox::warning(this, "Login Failed", "Please enter both ID and Password.");
        }
    });
}


void MainWindow::populateSampleData() {
    booksTable->insertRow(0);
    booksTable->setItem(0, 0, new QTableWidgetItem("C++ Primer"));
    booksTable->setItem(0, 1, new QTableWidgetItem("Lippman"));
    booksTable->setItem(0, 2, new QTableWidgetItem("978-0321714114"));

    articlesTable->insertRow(0);
    articlesTable->setItem(0, 0, new QTableWidgetItem("AI in Education"));
    articlesTable->setItem(0, 1, new QTableWidgetItem("Dr. Smith"));
    articlesTable->setItem(0, 2, new QTableWidgetItem("10.1000/182"));

    loansTable->insertRow(0);
    loansTable->setItem(0, 0, new QTableWidgetItem("Meriem"));
    loansTable->setItem(0, 1, new QTableWidgetItem("C++ Primer"));
    loansTable->setItem(0, 2, new QTableWidgetItem("2025-06-10"));
    loansTable->setItem(0, 3, new QTableWidgetItem("2025-06-20"));

    reservationsTable->insertRow(0);
    reservationsTable->setItem(0, 0, new QTableWidgetItem("Meriem"));
    reservationsTable->setItem(0, 1, new QTableWidgetItem("AI in Education"));
    reservationsTable->setItem(0, 2, new QTableWidgetItem("2025-06-12"));
}

// ------- Navigation Slots -------

void MainWindow::showBooksPage() {
    stackedWidget->setCurrentWidget(booksPage);
}

void MainWindow::showArticlesPage() {
    stackedWidget->setCurrentWidget(articlesPage);
}

void MainWindow::showLoansPage() {
    stackedWidget->setCurrentWidget(loansPage);
}

void MainWindow::showReservationsPage() {
    stackedWidget->setCurrentWidget(reservationsPage);
}

void MainWindow::returnToMainMenu() {
    stackedWidget->setCurrentWidget(mainMenuPage);
}
