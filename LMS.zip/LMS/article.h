#ifndef ARTICLE_H
#define ARTICLE_H

#include "resource.h"

class Article : public Resource {
private:
    std::string journalName;
    int volume;
    int issue;
    std::string DOI;

public:
    Article(const std::string& title, const std::string& author, int year,
            const std::string& id, const std::string& journal,
            int volume, int issue, const std::string& doi);

    // Implement pure virtual functions
    void displayDetails() const override;
    std::string getResourceType() const override;

    // Article-specific methods
    std::string getJournalName() const;
    int getVolume() const;
    int getIssue() const;
    std::string getDOI() const;
};

#endif // ARTICLE_H


