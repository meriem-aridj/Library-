#include "notification.h"
#include <iostream>
#include <stdexcept>
#include <regex>

// EmailNotification implementation
EmailNotification::EmailNotification(const std::string& server, int port,
                                     const std::string& sender, bool ssl)
    : smtpServer(server), port(port), senderEmail(sender), useSSL(ssl)
{
    // Validate constructor parameters
    if (server.empty()) {
        throw std::invalid_argument("SMTP server address cannot be empty");
    }
    if (port <= 0 || port > 65535) {
        throw std::out_of_range("Port must be between 1 and 65535");
    }

    // Basic email format validation
    const std::regex email_pattern(R"(\w+@\w+\.\w+)");
    if (!std::regex_match(sender, email_pattern)) {
        throw std::invalid_argument("Invalid sender email format");
    }
}

bool EmailNotification::send(const std::string& recipient,
                             const std::string& message) const
{
    // Validate recipient and message
    if (recipient.empty()) {
        throw std::invalid_argument("Recipient email cannot be empty");
    }

    const std::regex email_pattern(R"(\w+@\w+\.\w+)");
    if (!std::regex_match(recipient, email_pattern)) {
        throw std::invalid_argument("Invalid recipient email format");
    }

    if (message.empty()) {
        throw std::invalid_argument("Message content cannot be empty");
    }

    // Simulate email sending (replace with actual SMTP implementation)
    std::cout << "=== Sending Email ===\n"
              << "From: " << senderEmail << "\n"
              << "To: " << recipient << "\n"
              << "Server: " << smtpServer << ":" << port
              << " (SSL: " << (useSSL ? "enabled" : "disabled") << ")\n"
              << "Message: " << message << "\n\n";

    // Simulate 90% success rate for testing
    return (rand() % 10) != 0;
}

// Factory function implementation
std::unique_ptr<Notification> createEmailNotifier(
    const std::string& server,
    int port,
    const std::string& sender,
    bool ssl)
{
    try {
        return std::make_unique<EmailNotification>(server, port, sender, ssl);
    } catch (const std::exception& e) {
        std::cerr << "Failed to create email notifier: " << e.what() << std::endl;
        return nullptr;
    }
}
