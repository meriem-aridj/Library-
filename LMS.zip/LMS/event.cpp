#include "event.h"
#include "user.h"
#include <ctime>
#include <algorithm>
#include <stdexcept>
#include <iostream>
using namespace std ;

Event::Event(const std::string& id, const std::string& title,
             const std::string& desc, time_t start, time_t end,
             const std::string& loc, int capacity)
    : eventID(id), title(title), description(desc),
    startTime(start), endTime(end), location(loc),
    capacity(capacity) {
    if (startTime >= endTime) {
        throw std::invalid_argument("End time must be after start time");
    }
    if (capacity <= 0) {
        throw std::invalid_argument("Capacity must be positive");
    }
}

bool Event::registerUser(User* user) {
    if (!user) {
        return false;
    }
    if (registeredUsers.size() >= static_cast<size_t>(capacity)) {
        return false;
    }
    if (std::find(registeredUsers.begin(), registeredUsers.end(), user) != registeredUsers.end()) {
        return false; // User already registered
    }
    registeredUsers.push_back(user);
    return true;
}

bool Event::cancelRegistration(User* user) {
    auto it = std::find(registeredUsers.begin(), registeredUsers.end(), user);
    if (it == registeredUsers.end()) {
        return false;
    }
    registeredUsers.erase(it);
    return true;
}

int Event::getAvailableSeats() const {
    return capacity - static_cast<int>(registeredUsers.size());
}

void Event::displayDetails() const {
    std::cout << "EVENT DETAILS\n"
              << "ID: " << eventID << "\n"
              << "Title: " << title << "\n"
              << "Description: " << description << "\n"
              << "Start: " << std::ctime(&startTime)
              << "End: " << std::ctime(&endTime)
              << "Location: " << location << "\n"
              << "Capacity: " << registeredUsers.size() << "/" << capacity << "\n"
              << "Type: " << getEventType() << "\n";
}

std::string Event::getEventID() const {
    return eventID;
}

std::string Event::getTitle() const {
    return title;
}

std::string Event::getDescription() const {
    return description;
}

time_t Event::getStartTime() const {
    return startTime;
}

time_t Event::getEndTime() const {
    return endTime;
}

std::string Event::getLocation() const {
    return location;
}

int Event::getCapacity() const {
    return capacity;
}

std::vector<User*> Event::getRegisteredUsers() const {
    return registeredUsers;
}
