#ifndef NOTIFICATION_H
#define NOTIFICATION_H

#include <string>
#include <memory>

class Notification {
public:
    virtual ~Notification() = default;
    virtual bool send(const std::string& recipient, const std::string& message) const = 0;
    virtual std::string getType() const = 0;
};

// Email Notification
class EmailNotification : public Notification {
private:
    std::string smtpServer;
    int port;
    std::string senderEmail;
    bool useSSL;

public:
    EmailNotification(const std::string& server, int port,
                      const std::string& sender, bool ssl = true);

    bool send(const std::string& recipient, const std::string& message) const override;
    std::string getType() const override { return "Email"; }
};

// Factory function
std::unique_ptr<Notification> createEmailNotifier(
    const std::string& server = "smtp.example.com",
    int port = 587,
    const std::string& sender = "library@example.com",
    bool ssl = true);

#endif // NOTIFICATION_H
