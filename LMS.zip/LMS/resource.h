#ifndef RESOURCE_H
#define RESOURCE_H

#include <string>
#include <vector>
#include <ctime>

class Resource {
protected:
    std::string title;
    std::string author;
    int publicationYear;
    bool available;
    std::string resourceType;
    std::string uniqueID;

public:
    Resource(const std::string& title, const std::string& author, int year, const std::string& id);
    virtual ~Resource() = default;

    // Pure virtual functions (making this an abstract class)
    virtual void displayDetails() const = 0;
    virtual std::string getResourceType() const = 0;

    // Common methods for all resources
    virtual bool isAvailable() const;
    virtual void setAvailable(bool availability);
    virtual std::string getTitle() const;
    virtual std::string getAuthor() const;
    virtual int getPublicationYear() const;
    virtual std::string getUniqueID() const;
};

#endif // RESOURCE_H
