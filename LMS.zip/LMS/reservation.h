#ifndef RESERVATION_H
#define RESERVATION_H

#include "resource.h"
#include "user.h"
#include <ctime>

class Reservation {
private:
    Resource* resource;
    User* user;
    time_t reservationDate;
    bool fulfilled;

public:
    Reservation(Resource* resource, User* user, time_t reservationDate);

    Resource* getResource() const;
    User* getUser() const;
    time_t getReservationDate() const;
    bool isFulfilled() const;
    void fulfill();
};

#endif // RESERVATION_H
