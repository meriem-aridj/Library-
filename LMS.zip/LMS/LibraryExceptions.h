#ifndef LIBRARYEXCEPTIONS_H
#define LIBRARYEXCEPTIONS_H

// LibraryExceptions.h
#pragma once
#include <stdexcept>
#include "Loan.h"

class BorrowLimitReached : public std::runtime_error {
public:
    BorrowLimitReached()
        : std::runtime_error("User has reached the maximum allowed loans") {}
};
class overdue : public std::runtime_error {
public:
    overdue()
        : std::runtime_error("you should have returned the book before ") {}
};




#endif // LIBRARYEXCEPTIONS_H
