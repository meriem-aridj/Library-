#ifndef THESIS_H
#define THESIS_H

#include "Resource.h"

class Thesis : public Resource {
private:
    std::string university;
    std::string department;
    std::string degreeType;

public:
    Thesis(const std::string& title, const std::string& author, int year,
           const std::string& id, const std::string& university,
           const std::string& department, const std::string& degree);

    // Implement pure virtual functions
    void displayDetails() const override;
    std::string getResourceType() const override;

    // Thesis-specific methods
    std::string getUniversity() const;
    std::string getDepartment() const;
    std::string getDegreeType() const;
};

#endif // THESIS_H
