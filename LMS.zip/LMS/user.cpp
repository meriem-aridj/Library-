
#include "user.h"
#include "loan.h"
#include "event.h"

#include <algorithm>

User::User(const std::string& id, const std::string& name, const std::string& email)
    : userID(id), name(name), email(email), accountActive(true) {}

User::~User() {
    // Proper cleanup if needed
}

// -------- Loan-related Methods --------

bool User::canBorrow() const {
    return accountActive && currentLoans.size() < static_cast<size_t>(getMaxLoans());
}

void User::borrowResource(Loan* loan) {
    if (loan && canBorrow()) {
        currentLoans.push_back(loan);
    }
}

void User::returnResource(const std::string& resourceID) {
    auto it = std::find_if(currentLoans.begin(), currentLoans.end(),
                           [&resourceID](Loan* loan) {
                               return loan && loan->getResource()->getUniqueID() == resourceID;
                           });

    if (it != currentLoans.end()) {
        (*it)->returnResource();
        loanHistory.push_back(*it);
        currentLoans.erase(it);
    }
}

std::vector<Loan*> User::getCurrentLoans() const {
    return currentLoans;
}

std::vector<Loan*> User::getLoanHistory() const {
    return loanHistory;
}

// -------- User Info Methods --------

std::string User::getUserID() const {
    return userID;
}

std::string User::getName() const {
    return name;
}

std::string User::getEmail() const {
    return email;
}

// -------- Event-related Methods --------

bool User::registerForEvent(Event* event) {
    if (event && std::find(registeredEvents.begin(), registeredEvents.end(), event) == registeredEvents.end()) {
        registeredEvents.push_back(event);
        return true;
    }
    return false;
}

bool User::cancelEventRegistration(Event* event) {
    auto it = std::find(registeredEvents.begin(), registeredEvents.end(), event);
    if (it != registeredEvents.end()) {
        registeredEvents.erase(it);
        return true;
    }
    return false;
}

std::vector<Event*> User::getRegisteredEvents() const {
    return registeredEvents;
}

// -------- Account Status Methods --------

bool User::isActive() const {
    return accountActive;
}

void User::deactivate() {
    accountActive = false;
}

void User::activate() {
    accountActive = true;
}
