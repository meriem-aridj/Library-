#ifndef CONFERENCE_H
#define CONFERENCE_H

#include "event.h"
#include <vector>

class Speaker {
    std::string name;
    std::string affiliation;
    std::string topic;

public:
    Speaker(const std::string& name, const std::string& affiliation,
            const std::string& topic);

    std::string getName() const;
    std::string getAffiliation() const;
    std::string getTopic() const;
};

class Conference : public Event {
private:
    std::vector<Speaker> speakers;
    std::string theme;

public:
    Conference(const std::string& id, const std::string& title,
               const std::string& desc, time_t start, time_t end,
               const std::string& loc, int capacity,
               const std::string& theme);

    // Implement pure virtual function
    std::string getEventType() const override;

    // Conference-specific methods
    void addSpeaker(const Speaker& speaker);
    std::vector<Speaker> getSpeakers() const;
    std::string getTheme() const;
};

#endif // CONFERENCE_H
