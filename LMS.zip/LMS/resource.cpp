#include "resource.h"
#include <string>
Resource::Resource(const std::string &title, const std::string &author, int year, const std::string &id)
    : title (title), author (author), publicationYear(year) , uniqueID(id){}

bool Resource::isAvailable() const
{
    return available;
}

void Resource::setAvailable(bool availability)
{
    available=availability ;
}

std::string Resource::getTitle() const
{
    return title ;
}

std::string Resource::getAuthor() const
{
    return author ;
}

int Resource::getPublicationYear() const
{
    return publicationYear;
}

std::string Resource::getUniqueID() const
{
    return uniqueID;
}
