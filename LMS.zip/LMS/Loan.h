#ifndef LOAN_H
#define LOAN_H
#include "resource.h"
#include <ctime>

class User ;
class Loan {
private:
    Resource* resource;
    User* user;
    time_t loanDate;
    time_t dueDate;
    bool returned;
    time_t returnDate = 0 ;

public:
    Loan(Resource* resource, User* user, time_t loanDate, time_t dueDate);

    Resource* getResource() const;
    User* getUser() const;
    time_t getLoanDate() const;
    time_t getDueDate() const;
    bool isReturned() const;
    time_t getReturnDate() const;
    void returnResource();
    bool isOverdue() const;
};

#endif // LOAN_H
