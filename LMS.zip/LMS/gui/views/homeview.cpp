#include "homeview.h"

HomeView::HomeView(QWidget *parent) : QWidget(parent) {
    setupLayout();
}

void HomeView::setupLayout() {
    booksButton = new QPushButton("Books");
    articlesButton = new QPushButton("Articles");
    loansButton = new QPushButton("Loans");
    reservationsButton = new QPushButton("Reservations");

    QList<QPushButton*> buttons = { booksButton, articlesButton, loansButton, reservationsButton };
    for (auto* btn : buttons) {
        btn->setFixedSize(180, 42);
        btn->setStyleSheet(
            "QPushButton {"
            "  background-color: #f5f5f5;"
            "  border: 1px solid #cccccc;"
            "  border-radius: 10px;"
            "  font-size: 15px;"
            "  padding: 6px;"
            "  font-weight: 500;"
            "  color: #333333;"
            "}"
            "QPushButton:hover { background-color: #e6e6e6; }"
            );
    }

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setSpacing(20);
    layout->setAlignment(Qt::AlignCenter);

    layout->addWidget(booksButton);
    layout->addWidget(articlesButton);
    layout->addWidget(loansButton);
    layout->addWidget(reservationsButton);

    connect(booksButton, &QPushButton::clicked, this, &HomeView::booksClicked);
    connect(articlesButton, &QPushButton::clicked, this, &HomeView::articlesClicked);
    connect(loansButton, &QPushButton::clicked, this, &HomeView::loansClicked);
    connect(reservationsButton, &QPushButton::clicked, this, &HomeView::reservationsClicked);
}
