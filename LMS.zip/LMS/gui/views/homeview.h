#ifndef HOMEVIEW_H
#define HOMEVIEW_H

#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>

class HomeView : public QWidget {
    Q_OBJECT

public:
    explicit HomeView(QWidget *parent = nullptr);

signals:
    void booksClicked();
    void articlesClicked();
    void loansClicked();
    void reservationsClicked();

private:
    QPushButton* booksButton;
    QPushButton* articlesButton;
    QPushButton* loansButton;
    QPushButton* reservationsButton;

    void setupLayout();
};

#endif // HOMEVIEW_H
