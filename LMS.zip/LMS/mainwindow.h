#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QPushButton>
#include <QTableWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>
#include <QLabel>

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void showBooksPage();
    void showArticlesPage();
    void showLoansPage();
    void showReservationsPage();
    void returnToMainMenu();

private:
    QStackedWidget* stackedWidget;

    // Pages
    QWidget* mainMenuPage;
    QWidget* booksPage;
    QWidget* articlesPage;
    QWidget* loansPage;
    QWidget* reservationsPage;

    // Tables
    QTableWidget* booksTable;
    QTableWidget* articlesTable;
    QTableWidget* loansTable;
    QTableWidget* reservationsTable;

    // Setup helpers
    void setupMainMenu();
    void setupBooksPage();
    void setupArticlesPage();
    void setupLoansPage();
    void setupReservationsPage();
    void setupLoginPage();
    QLineEdit* booksSearchBox;
    // Add this under 'private:' in MainWindow
    QWidget* loginPage;
    QLineEdit* idInput;
    QLineEdit* passwordInput;
    QComboBox* roleSelector;
    QPushButton* loginButton;



    // Optional: temporary sample data population
    void populateSampleData();
};

#endif // MAINWINDOW_H
