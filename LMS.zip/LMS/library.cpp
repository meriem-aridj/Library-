#include "library.h"
#include <algorithm>
#include <ctime>
#include <stdexcept>
#include <iostream>
using namespace std ;

// Resource Management
void Library::addResource(std::unique_ptr<Resource> resource) {
    if (!resource) {
        throw std::invalid_argument("Cannot add null resource");
    }
    resources.push_back(std::move(resource));
}

bool Library::removeResource(const std::string& resourceID) {
    auto it = std::find_if(resources.begin(), resources.end(),
                           [&](const auto& res) { return res->getUniqueID() == resourceID; });

    if (it != resources.end()) {
        resources.erase(it);
        return true;
    }
    return false;
}

Resource* Library::findResource(const std::string& resourceID) const {
    auto it = std::find_if(resources.begin(), resources.end(),
                           [&](const auto& res) { return res->getUniqueID() == resourceID; });

    if (it != resources.end()) {
        return it->get();
    }
    throw std::runtime_error("Resource not found: " + resourceID);
}

std::vector<Resource*> Library::searchResources(const std::string& query) const {
    std::vector<Resource*> results;
    for (const auto& res : resources) {
        if (res->getTitle().find(query) != std::string::npos ||
            res->getAuthor().find(query) != std::string::npos) {
            results.push_back(res.get());
        }
    }
    return results;
}

// User Management
void Library::addUser(std::unique_ptr<User> user) {
    if (!user) {
        throw std::invalid_argument("Cannot add null user");
    }
    users.push_back(std::move(user));
}

bool Library::removeUser(const std::string& userID) {
    auto it = std::find_if(users.begin(), users.end(),
                           [&](const auto& user) { return user->getUserID() == userID; });

    if (it != users.end()) {
        users.erase(it);
        return true;
    }
    return false;
}

User* Library::findUser(const std::string& userID) const {
    auto it = std::find_if(users.begin(), users.end(),
                           [&](const auto& user) { return user->getUserID() == userID; });

    if (it != users.end()) {
        return it->get();
    }
    throw std::runtime_error("User not found: " + userID);
}

// Loan Management
bool Library::borrowResource(const std::string& userID, const std::string& resourceID) {
    User* user = findUser(userID);
    Resource* resource = findResource(resourceID);

    if (!resource->isAvailable()) {
        return false;
    }

    time_t now = time(nullptr);
    time_t dueDate = now + (14 * 24 * 3600); // 14 days later

    loans.push_back(std::make_unique<Loan>(resource, user, now, dueDate));
    resource->setAvailable(false);
    return true;
}

bool Library::returnResource(const std::string& resourceID) {
    auto it = std::find_if(loans.begin(), loans.end(),
                           [&](const auto& loan) { return loan->getResource()->getUniqueID() == resourceID && !loan->isReturned(); });

    if (it != loans.end()) {
        (*it)->returnResource();
        (*it)->getResource()->setAvailable(true);
        return true;
    }
    return false;
}

std::vector<Loan*> Library::getUserLoans(const std::string& userID) const {
    std::vector<Loan*> result;
    for (const auto& loan : loans) {
        if (loan->getUser()->getUserID() == userID && !loan->isReturned()) {
            result.push_back(loan.get());
        }
    }
    return result;
}

// Reservation Management
bool Library::makeReservation(const std::string& userID, const std::string& resourceID) {
    User* user = findUser(userID);
    Resource* resource = findResource(resourceID);

    if (resource->isAvailable()) {
        return false; // No need to reserve available resources
    }

    time_t now = time(nullptr);
    reservations.push_back(std::make_unique<Reservation>(resource, user, now));
    return true;
}

bool Library::fulfillReservation(const std::string& resourceID) {
    auto it = std::find_if(reservations.begin(), reservations.end(),
                           [&](const auto& res) { return res->getResource()->getUniqueID() == resourceID && !res->isFulfilled(); });

    if (it != reservations.end()) {
        (*it)->fulfill();
        return true;
    }
    return false;
}

std::vector<Reservation*> Library::getResourceReservations(const std::string& resourceID) const {
    std::vector<Reservation*> result;
    for (const auto& res : reservations) {
        if (res->getResource()->getUniqueID() == resourceID) {
            result.push_back(res.get());
        }
    }
    return result;
}

// Event Management
void Library::addEvent(std::unique_ptr<Event> event) {
    if (!event) {
        throw std::invalid_argument("Cannot add null event");
    }
    events.push_back(std::move(event));
}

bool Library::removeEvent(const std::string& eventID) {
    auto it = std::find_if(events.begin(), events.end(),
                           [&](const auto& event) { return event->getEventID() == eventID; });

    if (it != events.end()) {
        events.erase(it);
        return true;
    }
    return false;
}

Event* Library::findEvent(const std::string& eventID) const {
    auto it = std::find_if(events.begin(), events.end(),
                           [&](const auto& event) { return event->getEventID() == eventID; });

    if (it != events.end()) {
        return it->get();
    }
    throw std::runtime_error("Event not found: " + eventID);
}

std::vector<Event*> Library::getUpcomingEvents() const {
    std::vector<Event*> result;
    time_t now = time(nullptr);

    for (const auto& event : events) {
        if (event->getStartTime() > now) {
            result.push_back(event.get());
        }
    }

    std::sort(result.begin(), result.end(),
              [](Event* a, Event* b) { return a->getStartTime() < b->getStartTime(); });

    return result;
}

std::vector<Event*> Library::searchEvents(const std::string& query) const {
    std::vector<Event*> result;
    for (const auto& event : events) {
        if (event->getTitle().find(query) != std::string::npos ||
            event->getDescription().find(query) != std::string::npos) {
            result.push_back(event.get());
        }
    }
    return result;
}

bool Library::registerForEvent(const std::string& userID, const std::string& eventID) {
    User* user = findUser(userID);
    Event* event = findEvent(eventID);
    return event->registerUser(user);
}

bool Library::cancelEventRegistration(const std::string& userID, const std::string& eventID) {
    User* user = findUser(userID);
    Event* event = findEvent(eventID);
    return event->cancelRegistration(user);
}

// Notification System
void Library::checkDueDates() const {
    time_t now = time(nullptr);
    for (const auto& loan : loans) {
        if (!loan->isReturned() && loan->getDueDate() < now) {
            // In real implementation, send notification
            std::cout << "Overdue: " << loan->getResource()->getTitle()
                      << " borrowed by " << loan->getUser()->getName() << "\n";
        }
    }
}
