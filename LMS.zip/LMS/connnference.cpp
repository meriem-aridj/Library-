#include "connnference.h"


Speaker::Speaker(const std::string& name, const std::string& affiliation,
                 const std::string& topic)
    : name(name), affiliation(affiliation), topic(topic) {}

std::string Speaker::getName() const {
    return name;
}

std::string Speaker::getAffiliation() const {
    return affiliation;
}

std::string Speaker::getTopic() const {
    return topic;
}

Conference::Conference(const std::string& id, const std::string& title,
                       const std::string& desc, time_t start, time_t end,
                       const std::string& loc, int capacity,
                       const std::string& theme)
    : Event(id, title, desc, start, end, loc, capacity), theme(theme) {}

std::string Conference::getEventType() const {
    return "Conference";
}

void Conference::addSpeaker(const Speaker& speaker) {
    speakers.push_back(speaker);
}

std::vector<Speaker> Conference::getSpeakers() const {
    return speakers;
}

std::string Conference::getTheme() const {
    return theme;
}
