
#ifndef WORKSHOP_H
#define WORKSHOP_H

#include "event.h"

class Workshop : public Event {
private:
    std::string facilitator;
    std::string topic;
    std::vector<std::string> materials;

public:
    Workshop(const std::string& id, const std::string& title,
             const std::string& desc, time_t start, time_t end,
             const std::string& loc, int capacity,
             const std::string& facilitator, const std::string& topic);

    // Implement pure virtual function
    std::string getEventType() const override;

    // Workshop-specific methods
    void addMaterial(const std::string& material);
    std::vector<std::string> getMaterials() const;
    std::string getFacilitator() const;
    std::string getTopic() const;
};

#endif // WORKSHOP_H
