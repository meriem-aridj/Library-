#include "book.h"
#include <iostream>

Book::Book(const std::string& title, const std::string& author, int year,
           const std::string& id, const std::string& isbn,
           const std::string& publisher, int pages)
    : Resource(title, author, year, id),
    ISBN(isbn),
    publisher(publisher),
    pageCount(pages) {}

void Book::displayDetails() const {
    std::cout << "=== Book Details ===" << std::endl;
    std::cout << "Title: " << getTitle() << std::endl;
    std::cout << "Author: " << getAuthor() << std::endl;
    std::cout << "Year: " << getPublicationYear() << std::endl;
    std::cout << "ID: " << getUniqueID() << std::endl;
    std::cout << "ISBN: " << ISBN << std::endl;
    std::cout << "Publisher: " << publisher << std::endl;
    std::cout << "Page Count: " << pageCount << std::endl;
}

std::string Book::getResourceType() const {
    return "Book";
}

std::string Book::getISBN() const {
    return ISBN;
}

std::string Book::getPublisher() const {
    return publisher;
}

int Book::getPageCount() const {
    return pageCount;
}
