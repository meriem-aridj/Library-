#include "thesis.h"
#include <iostream>
#include <iomanip>

Thesis::Thesis(const std::string& title, const std::string& author, int year,
               const std::string& id, const std::string& university,
               const std::string& department, const std::string& degree)
    : Resource(title, author, year, id),
    university(university),
    department(department),
    degreeType(degree)
{
    if (university.empty()) throw std::invalid_argument("University cannot be empty");
    if (department.empty()) throw std::invalid_argument("Department cannot be empty");
    if (degree.empty()) throw std::invalid_argument("Degree type cannot be empty");
}

void Thesis::displayDetails() const {
    std::cout << "\n=== THESIS DETAILS ===\n"
              << "Title:     " << getTitle() << "\n"
              << "Author:    " << getAuthor() << "\n"
              << "University:" << university << "\n"
              << "Department:" << department << "\n"
              << "Degree:    " << degreeType << "\n"
              << "Year:      " << getPublicationYear() << "\n"
              << "ID:        " << getUniqueID() << "\n"
              << "Status:    " << (isAvailable() ? "Available" : "Checked Out") << "\n";
}

std::string Thesis::getResourceType() const {
    return "Thesis";
}

std::string Thesis::getUniversity() const {
    return university;
}

std::string Thesis::getDepartment() const {
    return department;
}

std::string Thesis::getDegreeType() const {
    return degreeType;
}
