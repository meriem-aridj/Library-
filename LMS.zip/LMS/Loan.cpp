#include "loan.h"
#include <ctime>

// Constructor
Loan::Loan(Resource* resource, User* user, time_t loanDate, time_t dueDate)
    : resource(resource), user(user), loanDate(loanDate), dueDate(dueDate),
    returned(false), returnDate(0) {}

// Getters
Resource* Loan::getResource() const {
    return resource;
}

User* Loan::getUser() const {
    return user;
}

time_t Loan::getLoanDate() const {
    return loanDate;
}

time_t Loan::getDueDate() const {
    return dueDate;
}

bool Loan::isReturned() const {
    return returned;
}

time_t Loan::getReturnDate() const {
    return returnDate;
}

// Return the resource
void Loan::returnResource() {
    if (!returned) {
        returned = true;
        returnDate = std::time(nullptr);
        resource->setAvailable(true);  // Optional: mark as available again
    }
}

// Check if overdue
bool Loan::isOverdue() const {
    if (returned) return false;
    time_t now = std::time(nullptr);
    return now > dueDate;
}
