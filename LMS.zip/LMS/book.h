#ifndef BOOK_H
#define BOOK_H

#include "resource.h"

class Book : public Resource {
private:
    std::string ISBN;
    std::string publisher;
    int pageCount;

public:
    Book(const std::string& title, const std::string& author, int year,
         const std::string& id, const std::string& isbn,
         const std::string& publisher, int pages);

    // Implement pure virtual functions
    void displayDetails() const override;
    std::string getResourceType() const override;

    // Book-specific methods
    std::string getISBN() const;
    std::string getPublisher() const;
    int getPageCount() const;
};

#endif // BOOK_H
