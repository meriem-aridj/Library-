#ifndef STUDENT_H
#define STUDENT_H

#include "user.h"

class Student : public User {
private:
    std::string studentID;
    std::string program;
    int semester;

public:
    Student(const std::string& id, const std::string& name,
            const std::string& email, const std::string& studentID,
            const std::string& program, int semester);

    // Implement pure virtual function
    int getMaxLoans() const override;

    // Student-specific methods
    std::string getStudentID() const;
    std::string getProgram() const;
    int getSemester() const;
};

#endif // STUDENT_H
