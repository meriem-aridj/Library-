#ifndef FACULTY_H
#define FACULTY_H

#include "user.h"

class Faculty : public User {
private:
    std::string facultyID;
    std::string department;
    std::string position;

public:
    Faculty(const std::string& id, const std::string& name,
            const std::string& email, const std::string& facultyID,
            const std::string& department, const std::string& position);

    // Implement pure virtual function
    int getMaxLoans() const override;

    // Faculty-specific methods
    std::string getFacultyID() const;
    std::string getDepartment() const;
    std::string getPosition() const;
};

#endif // FACULTY_H
