#ifndef USER_H
#define USER_H

#include <string>
#include <vector>

// Forward declarations
class Loan;
class Event;

class User {
protected:
    std::string userID;
    std::string name;
    std::string email;
    std::vector<Loan*> currentLoans;
    std::vector<Loan*> loanHistory;
    std::vector<Event*> registeredEvents;
    bool accountActive = true;

public:
    User(const std::string& id, const std::string& name, const std::string& email);
    virtual ~User();  // Non-inline virtual destructor ensures correct cleanup for derived classes

    // Pure virtual function
    virtual int getMaxLoans() const = 0;

    // Loan-related methods
    bool canBorrow() const;
    void borrowResource(Loan* loan);
    void returnResource(const std::string& resourceID);
    std::vector<Loan*> getCurrentLoans() const;
    std::vector<Loan*> getLoanHistory() const;

    // User info
    std::string getUserID() const;
    std::string getName() const;
    std::string getEmail() const;

    // Event-related methods
    bool registerForEvent(Event* event);
    bool cancelEventRegistration(Event* event);
    std::vector<Event*> getRegisteredEvents() const;

    // Account status
    bool isActive() const;
    void deactivate();
    void activate();
};

#endif // USER_H
